# Deploy WatPhasa Legal Pages

These static HTML pages are ready to upload to:

- `https://wpprecisionsystems.co.uk/watphasa/`
- `https://wpprecisionsystems.co.uk/watphasa/privacy/`
- `https://wpprecisionsystems.co.uk/watphasa/terms/`
- `https://wpprecisionsystems.co.uk/watphasa/delete-account/`

## Files To Upload

Upload the contents of this `legal-pages` folder into the website folder:

```text
public_html/watphasa/
```

The final server structure should look like:

```text
public_html/
  watphasa/
    index.html
    style.css
    privacy.html
    terms.html
    delete-account.html
    privacy/
      index.html
    terms/
      index.html
    delete-account/
      index.html
```

## Option 1: cPanel File Manager

1. Log in to your website hosting cPanel.
2. Open File Manager.
3. Open `public_html`.
4. Create a folder named `watphasa`.
5. Upload all files and folders from:

```text
C:\Users\Warin\Documents\thai-eng app\legal-pages
```

6. Confirm these URLs open in a private/incognito browser:

```text
https://wpprecisionsystems.co.uk/watphasa/privacy/
https://wpprecisionsystems.co.uk/watphasa/terms/
https://wpprecisionsystems.co.uk/watphasa/delete-account/
```

## Option 2: FTP

1. Connect to your website using FileZilla or another FTP client.
2. Open the remote folder `public_html`.
3. Create `watphasa`.
4. Upload all contents of this folder into `public_html/watphasa`.
5. Test the URLs above.

## Option 3: Netlify

Use this only if you do not want to upload to the existing WP Precision Systems hosting.

1. Go to Netlify.
2. Add a new site by manual deploy.
3. Drag the `legal-pages` folder into Netlify.
4. Netlify will give you a temporary URL.
5. Add a custom domain or subdomain if needed.

## Google Play Console URLs

Use these in Play Console:

```text
Privacy Policy URL:
https://wpprecisionsystems.co.uk/watphasa/privacy/

Account deletion URL:
https://wpprecisionsystems.co.uk/watphasa/delete-account/

Terms URL, if requested:
https://wpprecisionsystems.co.uk/watphasa/terms/
```

## App Constants

The app currently points to:

```text
https://wpprecisionsystems.co.uk/watphasa/privacy
https://wpprecisionsystems.co.uk/watphasa/terms
https://wpprecisionsystems.co.uk/watphasa/delete-account
```

Most servers will load the same pages with or without the trailing slash. If your hosting requires the slash, update `src/constants/externalLinks.ts`.
